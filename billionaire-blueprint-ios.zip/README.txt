1. Upload to GitHub.
2. Enable GitHub Pages.
3. Optimized for iOS Safari (viewport-fit, no phone linking, PWA-ready).
4. Access it on your iPhone via Safari after publishing.